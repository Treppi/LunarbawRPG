package de.treppi.rpg.entities;

import java.util.Scanner;

import org.bukkit.configuration.file.FileConfiguration;

import de.treppi.rpg.core.Settings;
import de.treppi.rpg.core.main.Main;
import de.treppi.rpg.inventory.Inventory;

public class Player extends Fightable {
	private double health = Settings.playerHealth;
	private String name;
	private boolean named = false;
	private double damage = 1;
	private double range = 0.5;
	private Inventory inventory = new Inventory(Settings.playerInventorySize);
	private long playtime = 1;
	
	
	//actions
	public String input() {
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		String input = scanner.nextLine();  // Read user input
		return input;
	}
	public void send(String s) {
		System.out.println(s);
	}
	public void clearChat() {
		for(int i = 0; i < 80; i++) {
			this.send(" ");
		}
	}
	public void askForName() {
		if(this.isNamed() == true) return;
		this.send("Wie m�chtest du genannt werden?");
		System.out.print(">");
		this.setName(this.input());
		
		
		this.clearChat();
		this.send("hi, "+this.getName());
		this.send("Wenn dir dein Name nicht gef�llt, kannst du ihn sp�ter in den Einstellungen �ndern.");
		
	}
	public void save() {
		FileConfiguration config = Main.config;
		
		for(int i = 1; i < ++i; i+=0) {
			if(config.contains("players."+ Integer.toString(i)) == false) {
				String id = Integer.toString(i);
				
				config.set("players."+id+".name", this.getName());
				config.set("players."+id+".health", this.getHealth());
				config.set("players."+id+".damage", this.getDamage());
				config.set("players."+id+".playtime", this.getPlaytime());
				config.set("players."+id+".inventory", this.getInventory().getAsConfigString());
				
				Main.saveConfig();
				return;
			}
		}
		
		
		Main.saveConfig();
	}
	
	//setter, getter
	
	public boolean isNamed() {
		return this.named;
	}
	public double getDamage() {
		return damage;
	}
	public void setDamage(double damage) {
		this.damage = damage;
	}
	public double getRange() {
		return range;
	}
	public void setRange(double range) {
		this.range = range;
	}
	public void setNamed(boolean named) {
		this.named = named;
	}
	public void setInventory(Inventory inventory) {
		this.inventory = inventory;
	}
	public double getHealth() {
		return health;
	}
	public void setHealth(double health) {
		this.health = health;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Inventory getInventory() {
		return this.inventory;
	}
	public long getPlaytime() {
		return playtime;
	}
	public void setPlaytime(long playtime) {
		this.playtime = playtime;
	}
}
