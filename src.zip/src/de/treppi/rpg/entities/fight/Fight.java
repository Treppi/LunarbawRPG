package de.treppi.rpg.entities.fight;



import java.util.ArrayList;
import java.util.List;

import de.treppi.rpg.entities.Fightable;

public class Fight {
	private Fightable winner;
	private Fightable f1;
	private Fightable f2;
	
	public Fight(Fightable f1, Fightable f2) {
		this.f1 = f1;
		this.f2 = f2;
	}
	
	public void start() {
		
	}
	
	//getters & setters
	public Fightable getWinner() {
		return this.winner;
	}
	public Fightable getF1() {
		return this.f1;
	}
	public Fightable getF2() {
		return this.f2;
	}
	public List<Fightable> getFightables() {
		List<Fightable> list = new ArrayList<Fightable>();
		list.add(this.f1);
		list.add(this.f2);
		
		return list;
	}
}
