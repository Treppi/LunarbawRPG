package de.treppi.rpg.entities;

import java.util.ArrayList;

import de.treppi.rpg.core.main.Main;

public class Players {
	public static ArrayList<String> getAllPlayers() {
		int i = 0;
		ArrayList<String> players = new ArrayList<String>();
		while(i < ++i) {
			String id = Integer.toString(i);
			if(Main.config.contains("players."+id)) {
				
				players.add("players."+id+".name");
				
			}
			else break;
		}
		return players;
	}
}
