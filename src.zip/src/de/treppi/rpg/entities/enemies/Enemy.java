package de.treppi.rpg.entities.enemies;

import de.treppi.rpg.entities.Fightable;

public class Enemy extends Fightable {
	private String name;
	private double health;
	private double damage;
	private double range;
	
	public Enemy(String name, double health, double damage, double range) {
		this.name = name;
		this.health = health;
		this.damage = damage;
		this.range = range;
	}
	
	
	
	
}
