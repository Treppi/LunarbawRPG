package de.treppi.rpg.core;

public class Settings {
	public static double playerHealth = 10.0;
	public static int playerInventorySize = 100;
}
