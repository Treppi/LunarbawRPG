package de.treppi.rpg.core.main;

import java.io.File;
import java.io.IOException;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import de.treppi.rpg.entities.Player;
import de.treppi.rpg.entities.Players;
import de.treppi.rpg.helpers.FONT;
import de.treppi.rpg.inventory.items.Item;

public class Main {
	public static Player p = new Player();
	static File configFile = new File("storage/config.yml");
	public static FileConfiguration config = YamlConfiguration.loadConfiguration(configFile);
	
	
	public static void main(String[] args) {
		
		System.out.println(FONT.getTitle());
		FONT.getTitleLoadBar(p, 10, 200);
		p.clearChat();
		p.askForName();
		p.save();
		
		
		p.getInventory().addItem(new Item("Stein", 1.0));
		
		for(Item item : p.getInventory().getItems()) {
			p.send(item.getName());
		}
		for(String name : Players.getAllPlayers()) {
			p.send(name);
		}
		
		
		
		
		

	}
	public static void saveConfig(){
		try {
			config.save(configFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
