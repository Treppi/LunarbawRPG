package de.treppi.rpg.inventory.items;

public class Item {
	private double space;
	private String name;
	private String description;
	public Item(String name, double space) {
		this.name = name;
		this.space = space;
	}
	public double getSpace() {
		return space;
	}
	public void setSpace(double space) {
		this.space = space;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
