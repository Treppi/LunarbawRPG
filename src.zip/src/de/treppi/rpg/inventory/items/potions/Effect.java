package de.treppi.rpg.inventory.items.potions;

public class Effect {
	//irgendwie Zeitbegrenzt
}
