package de.treppi.rpg.inventory.items.potions;

import de.treppi.rpg.inventory.items.Item;

public class Potion extends Item {
	public Potion(String name, double space) {
		super(name, space);
	}
	private Effect effect;
	private int duration;
	private boolean throwable;
}
