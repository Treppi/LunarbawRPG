package de.treppi.rpg.inventory.items;

public class Weapon extends Item {

	private String name;
	private double space;
	private String description;
	
	public Weapon(String name, double space) {
		super(name, space);
	}
	
	
}
