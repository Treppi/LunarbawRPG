package de.treppi.rpg.inventory;

import java.util.ArrayList;

import de.treppi.rpg.inventory.items.Item;

public class Inventory {
	private int size;
	private ArrayList<Item> items = new ArrayList<Item>();
	
	public Inventory(int size) {
		this.size = size;
	}
	
	public String getAsConfigString() {
		return "ich muss das noch machen.";
	}
	public void addItem(Item i) {
		this.items.add(i);
	}
	public void removeItems(Item item, int count) {
		for(int i = 0; i < items.size(); i++) {
			if(item.getName().equalsIgnoreCase(items.get(i).getName())) {
				
				for(int j = 0; j < count; j++) {
					items.remove(i);
				}
			}
		}
	}
	
	//getters & setters
	public ArrayList<Item> getItems() {
		return this.items;
	}
}
