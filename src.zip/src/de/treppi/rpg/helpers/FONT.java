package de.treppi.rpg.helpers;

import de.treppi.rpg.entities.Player;

public class FONT {
	private static String title = "\r\r               Lunarbaw Play's \r\n" + 
			"       ____________________  ________ \r\n" + 
			"       \\______   \\______   \\/  _____/ \r\n" + 
			"        |       _/|     ___/   \\  ___ \r\n" + 
			"        |    |   \\|    |   \\    \\_\\  \\\r\n" + 
			"        |____|_  /|____|    \\______  /\r\n" + 
			"               \\/                  \\/\r\n "+
			"                   (by Treppi :3) \r\n";
	public static String getTitle() {
		return title;
	}
	public static void getTitleLoadBar(Player p, int amount, int delay) {
		String before = "       ";
		String after = "]";
		
		String loadSymbol = "#";
		for(int i = 1; i < amount+1; i++) {
			
			int space = amount;
			String dots = "";
			String spaceString = "";
			for(int j = 0; j < i; j++) {
				dots += loadSymbol;
				space--;
			}
			for(int k = 0; k < space; k++) {
				spaceString += " ";
				
			}
			space = 0;
			p.clearChat();
			p.send(getTitle());
			p.send(" ");
			p.send(before+ "Status: Loading...");
			String message = before+"["+dots+spaceString+after;
			p.send(message);
			
			try {
				Thread.sleep(delay);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	
}
