package de.treppi.rpg.helpers;

public class OUT {
	private static String debugPrefix = "[DEBUG]: ";
	public static boolean debug = false;
	public static void debug(String s) {
		if(debug) System.out.println(debugPrefix + s);
	}
}
